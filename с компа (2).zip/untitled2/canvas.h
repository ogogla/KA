#ifndef CANVAS_H
#define CANVAS_H

#include <QObject>
#include <QLabel>
#include <QPoint>
#include <QMouseEvent>

class Canvas : public QLabel
{
    Q_OBJECT
public:
    Canvas(QWidget *parent);
signals:
    void mouse_pressed(QPoint pos);
    void mouse_dragged(QPoint pos);
    void mouse_released(QPoint pos);
protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
};

#endif // CANVAS_H
