#include "canvas.h"

Canvas::Canvas(QWidget *parent) : QLabel(parent) {}

void Canvas::mousePressEvent(QMouseEvent *event)
{
    if (event->button() != Qt::LeftButton) return;
    emit this->mouse_pressed(event->pos());
}

void Canvas::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() != Qt::LeftButton) return;
    emit this->mouse_released(event->pos());
}

void Canvas::mouseMoveEvent(QMouseEvent *event)
{
    emit this->mouse_dragged(event->pos());
}
