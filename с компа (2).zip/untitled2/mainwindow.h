#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QApplication>
#include <QMainWindow>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QToolBar>
#include <QPixmap>
#include <QKeySequence>
#include <QLabel>
#include <QScrollArea>
#include <QColor>
#include <QFileDialog>
#include <QMessageBox>
#include <QPainter>
#include <QMouseEvent>
#include <QPoint>
#include <QDebug>
#include <QColorDialog>
#include <QToolBar>
#include <QTextStream>
#include <QClipboard>

#include "canvas.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

    enum STATES {
        MAIN_COLOR = 0,
        BACKGROUND_COLOR = 1,
        COLOR_CHOOSING = 2,
        LINE_WIDTH_CHOOSING = 4,
        PENCIL = 8,
        LINE = 16,
        RECTANGLE = 32,
        CIRCLE = 64,
        DRAWING = 128,
        CLEAR_INSTRUMENT = 0x87 // 100001111 - 0x87
    };

    QString filename;
    QString filename_save = nullptr;
    bool isSaveNeeded = false;
    QPixmap *mainBuffer = nullptr, *tempBuffer = nullptr, *displayBuffer = nullptr;
    Canvas *displayLabel;
    QScrollArea *displayArea;
    size_t width;
    size_t height;
    size_t lineWidth;
    QColor mainColor, backgroundColor;

    int baseX, baseY;

    int state;

    QMenuBar *menuBar;
    QMenu *fileMenu;
    QAction *newAction;
    QAction *openAction;
    QAction *saveAction;
    QAction *saveAsAction;
    QAction *copyToClipboard;
    QAction *pasteFromClipboard;
    QAction *exitAction;

    QMenu *toolsMenu;
    QAction *useMainColorAction;
    QAction *useBackgroundColorAction;
    QAction *chooseColorAction;
    QAction *chooseLineWidthAction;
    QAction *usePencil;
    QAction *useLine;
    QAction *useRectangle;
    QAction *useCircle;

    QToolBar *toolBar;

    QClipboard *clipboard;

    void clear(int width, int height);
    const QPixmap &makeColorIcon(const QColor& color);
    void draw_buffer(QPixmap *pixmap);

private slots:
    void on_new();
    void on_open();
    void on_save();
    void on_save_as();
    void on_copy_to_clipboard();
    void on_paste_from_clipboard();

    void on_swap_color();
    void on_choose_color();
    void on_choose_line_width();
    void on_use_pencil();
    void on_use_line();
    void on_use_rectangle();
    void on_use_circle();

    void on_mouse_pressed(QPoint pos);
    void on_mouse_released(QPoint pos);
    void on_mouse_dragged(QPoint pos);

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
};
#endif // MAINWINDOW_H
