#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    this->setWindowTitle(QString("Paint"));

    this->fileMenu = new QMenu("&Файл", this);
    this->newAction = this->fileMenu->addAction("&Новый", QKeySequence("Ctrl+N"), this, &MainWindow::on_new);
    this->openAction = this->fileMenu->addAction("&Открыть", QKeySequence("Ctrl+O"), this, &MainWindow::on_open);
    this->saveAction = this->fileMenu->addAction("&Сохранить", QKeySequence("Ctrl+S"), this, &MainWindow::on_save);
    this->saveAsAction = this->fileMenu->addAction("Сохранить &как", QKeySequence("Ctrl+Shift+S"), this, &MainWindow::on_save_as);
    this->fileMenu->addSeparator();
    this->copyToClipboard = this->fileMenu->addAction("Ско&пировать в буфер обмена", QKeySequence("Ctrl+C"), this, &MainWindow::on_copy_to_clipboard);
    this->pasteFromClipboard = this->fileMenu->addAction("&Вставить из буфера обмена", QKeySequence("Ctrl+V"), this, &MainWindow::on_paste_from_clipboard);
    this->fileMenu->addSeparator();
    this->exitAction = this->fileMenu->addAction("&Выйти", QKeySequence("Ctrl+Q"), QApplication::instance(), &QApplication::exit);


    this->toolsMenu = new QMenu("&Инструменты", this);
    this->useMainColorAction = this->toolsMenu->addAction("Основной &цвет", QKeySequence("Ctrl+W"), this, &MainWindow::on_swap_color);
    this->useBackgroundColorAction = this->toolsMenu->addAction("Цвет &фона", QKeySequence("Ctrl+E"), this, &MainWindow::on_swap_color);
    this->toolsMenu->addSeparator();
    this->chooseColorAction = this->toolsMenu->addAction("Изменить ц&вет", QKeySequence("Ctrl+A"), this, &MainWindow::on_choose_color);
    this->chooseLineWidthAction = this->toolsMenu->addAction("Изменить &ширину штриховки", QKeySequence("Ctrl+D"), this, &MainWindow::on_choose_line_width);
    this->toolsMenu->addSeparator();
    this->usePencil = this->toolsMenu->addAction(QIcon(":/icons/pencil.png"), "&Карандаш", QKeySequence("Ctrl+P"), this, &MainWindow::on_use_pencil);
    this->useLine = this->toolsMenu->addAction(QIcon(":/icons/line.png"), "&Линия", QKeySequence("Ctrl+L"), this, &MainWindow::on_use_line);
    this->useRectangle = this->toolsMenu->addAction(QIcon(":/icons/rectangle.png"), "&Прямоугольник", QKeySequence("Ctrl+R"), this, &MainWindow::on_use_rectangle);
    this->useCircle = this->toolsMenu->addAction(QIcon(":/icons/circle.png"), "&Окружность", QKeySequence("Ctrl+C"), this, &MainWindow::on_use_circle);

    this->menuBar = new QMenuBar(this);
    this->menuBar->addMenu(this->fileMenu);
    this->menuBar->addMenu(this->toolsMenu);
    this->setMenuBar(this->menuBar);

    this->setMenuBar(this->menuBar);

    this->displayArea = new QScrollArea;
    this->displayArea->setWidgetResizable(true);

    this->displayLabel = new Canvas(this);
    this->displayLabel->setAlignment(Qt::AlignTop);
    this->displayArea->setWidget(this->displayLabel);

    connect(this->displayLabel, SIGNAL(mouse_pressed(QPoint)), this, SLOT(on_mouse_pressed(QPoint)));
    connect(this->displayLabel, SIGNAL(mouse_released(QPoint)), this, SLOT(on_mouse_released(QPoint)));
    connect(this->displayLabel, SIGNAL(mouse_dragged(QPoint)), this, SLOT(on_mouse_dragged(QPoint)));


    this->setCentralWidget(this->displayArea);

    this->toolBar = new QToolBar("Инструменты", this);
    this->addToolBar(this->toolBar);

    this->toolBar->addAction(this->useMainColorAction);
    this->toolBar->addAction(this->useBackgroundColorAction);
    this->toolBar->addSeparator();
    this->toolBar->addAction(this->chooseColorAction);
    this->toolBar->addAction(this->chooseLineWidthAction);
    this->toolBar->addSeparator();
    this->toolBar->addAction(this->usePencil);
    this->toolBar->addAction(this->useLine);
    this->toolBar->addAction(this->useRectangle);
    this->toolBar->addAction(this->useCircle);

    this->clear(640, 480);
}

MainWindow::~MainWindow() {
    delete this->mainBuffer;
    delete this->tempBuffer;
    delete this->menuBar;
    delete this->fileMenu;
    delete this->newAction;
    delete this->openAction;
    delete this->saveAction;
    delete this->saveAsAction;
    delete this->exitAction;
    delete this->toolsMenu;
    delete this->useMainColorAction;
    delete this->useBackgroundColorAction;
    delete this->chooseColorAction;
    delete this->chooseLineWidthAction;
    delete this->usePencil;
    delete this->useLine;
    delete this->useRectangle;
    delete this->useCircle;
}


void MainWindow::clear(int width, int height)
{
    this->width = width;
    this->height = height;
    this->mainColor = QColor(0, 0, 0, 255);
    this->useMainColorAction->setIcon(this->makeColorIcon(this->mainColor));
    this->backgroundColor = QColor(255, 255, 255, 255);
    this->useBackgroundColorAction->setIcon(this->makeColorIcon(this->backgroundColor));

    if (this->mainBuffer != nullptr) delete this->mainBuffer;
    if (this->displayBuffer != nullptr) delete this->displayBuffer;

    this->mainBuffer = new QPixmap(this->width, this->height);
    this->mainBuffer->fill(this->backgroundColor);

    this->displayBuffer = new QPixmap(this->width, this->height);
    this->displayBuffer->fill(this->backgroundColor);

    this->displayLabel->setPixmap(*(this->displayBuffer));
}

const QPixmap &MainWindow::makeColorIcon(const QColor &color)
{
    QPixmap *icon = new QPixmap(16, 16);
    icon->fill(color);
    return *icon;
}

void MainWindow::on_new()
{
    this->clear(640, 480);
    this->isSaveNeeded = true;
}

void MainWindow::on_open()
{
    QString filename = QFileDialog::getOpenFileName(
        this,
        "Открыть изображение",
        "",
        ""
    );

    if (filename.isEmpty()) return;

    QPixmap *image = new QPixmap(filename);
    if (image->isNull()){
        QMessageBox::critical(
            this,
            "Ошибка чтения",
            "Не удалось открыть файл " + filename
        );
        return;
    }

    this->clear(image->width(), image->height());

    QPainter p1(this->mainBuffer);
    p1.drawPixmap(0, 0, this->width, this->height, *image);
    p1.end();

    this->draw_buffer(this->mainBuffer);
    this->isSaveNeeded = true;
}

void MainWindow::on_save()
{
    if (!this->isSaveNeeded) return;
    qInfo() << this->filename_save;
    if (this->filename_save.isEmpty()) {
        this->on_save_as();
        return;
    }
    if (!this->mainBuffer->save(this->filename_save)) {
        QMessageBox::critical(
            this,
            "Ошибка сохранения",
            "Не удалось сохранить файл в " + this->filename_save
            );
        return;
    }
    this->isSaveNeeded = false;
}

void MainWindow::on_save_as()
{
    QString filename = QFileDialog::getSaveFileName(
        this,
        "Сохранить файл как",
        "",
        ""
        );
    if (filename.isEmpty()) return;
    if (QFileInfo(filename).suffix().isEmpty()) {
        filename += ".png";
    }

    this->filename_save = filename;
    qInfo() << this->filename_save;
    this->on_save();
}

void MainWindow::on_copy_to_clipboard()
{
    this->clipboard = QGuiApplication::clipboard();
    this->clipboard->setPixmap(*this->mainBuffer);
}

void MainWindow::on_paste_from_clipboard()
{
    this->clipboard = QGuiApplication::clipboard();
    QPixmap pm = this->clipboard->pixmap();

    if (!pm.isNull()) {
        this->tempBuffer = new QPixmap(this->width, this->height);

        QPainter p(this->tempBuffer);
        p.drawPixmap(0, 0, pm);
        p.end();

        this->state &= ~STATES::DRAWING;

        QPixmap *t = this->mainBuffer;
        this->mainBuffer = this->tempBuffer;
        delete t;
        this->tempBuffer = nullptr;

        this->draw_buffer(this->mainBuffer);
        this->isSaveNeeded = true;
    } else {
        QMessageBox::information(
            this,
            "Путота",
            "В буфере нет изображения"
            );
    }
}

void MainWindow::on_swap_color()
{
    QColor t = this->mainColor;
    this->mainColor = this->backgroundColor;
    this->backgroundColor = t;

    this->useMainColorAction->setIcon(this->makeColorIcon(this->mainColor));
    this->useBackgroundColorAction->setIcon(this->makeColorIcon(this->backgroundColor));
}

void MainWindow::on_choose_color()
{
    QColor color = this->mainColor;
    if (this->state & STATES::BACKGROUND_COLOR)
        color = this->backgroundColor;
    color = QColorDialog::getColor(color, this, "Выберете цвет");
    if (color.isValid()) {
        if (this->state & STATES::BACKGROUND_COLOR)
            this->backgroundColor = color;
        else
            this->mainColor = color;
    }

    this->useMainColorAction->setIcon(this->makeColorIcon(this->mainColor));
    this->useBackgroundColorAction->setIcon(this->makeColorIcon(this->backgroundColor));
}

void MainWindow::on_choose_line_width()
{

}

void MainWindow::on_use_pencil()
{
    this->state &= STATES::CLEAR_INSTRUMENT;
    this->state |= STATES::PENCIL;
}

void MainWindow::on_use_line()
{
    this->state &= STATES::CLEAR_INSTRUMENT;
    this->state |= STATES::LINE;
}

void MainWindow::on_use_rectangle()
{
    this->state &= STATES::CLEAR_INSTRUMENT;
    this->state |= STATES::RECTANGLE;
}

void MainWindow::on_use_circle()
{
    this->state &= STATES::CLEAR_INSTRUMENT;
    this->state |= STATES::CIRCLE;
}


void MainWindow::on_mouse_pressed(QPoint pos)
{
    this->state |= STATES::DRAWING;
    this->baseX = pos.x();
    this->baseY = pos.y();

    if (this->tempBuffer != nullptr) delete this->tempBuffer;
    this->tempBuffer = new QPixmap(this->width, this->height);

    QPainter p(this->tempBuffer);
    p.drawPixmap(0, 0, *this->mainBuffer);
    p.end();
}

void MainWindow::on_mouse_released(QPoint pos)
{
    this->state &= ~STATES::DRAWING;

    QPixmap *t = this->mainBuffer;
    this->mainBuffer = this->tempBuffer;
    delete t;
    this->tempBuffer = nullptr;

    this->draw_buffer(this->mainBuffer);
    this->isSaveNeeded = true;
}

void MainWindow::on_mouse_dragged(QPoint pos)
{
    QPainter p(this->tempBuffer); // если кидать буферы в стек, то можно реализовать Ctrl+Z
    p.setPen(this->mainColor);
    p.setBrush(this->backgroundColor);

    if (this->state & STATES::PENCIL) {
        p.drawLine(this->baseX, this->baseY, pos.x(), pos.y());

        this->baseX = pos.x();
        this->baseY = pos.y();
    }

    if (this->state & STATES::LINE) {
        p.drawPixmap(0, 0, *this->mainBuffer);
        p.drawLine(this->baseX, this->baseY, pos.x(), pos.y());
    }

    if (this->state & STATES::RECTANGLE) {
        p.drawPixmap(0, 0, *this->mainBuffer);
        QColor transparent_color = this->backgroundColor;
        transparent_color.setAlpha(0);
        p.setBrush(transparent_color);
        p.drawRect(this->baseX, this->baseY, pos.x() - this->baseX, pos.y() - this->baseY);
        p.setBrush(this->backgroundColor);
    }

    if (this->state & STATES::CIRCLE) {
        p.drawPixmap(0, 0, *this->mainBuffer);
        QColor transparent_color = this->backgroundColor;
        transparent_color.setAlpha(0);
        p.setBrush(transparent_color);
        p.drawEllipse(this->baseX, this->baseY, pos.x() - this->baseX, pos.y() - this->baseY);
        p.setBrush(this->backgroundColor);
    }

    p.end();
    this->draw_buffer(this->tempBuffer);
}

void MainWindow::draw_buffer(QPixmap *pixmap)
{
    QPainter p(this->displayBuffer);
    p.drawPixmap(0, 0, *pixmap);
    p.end();
    this->displayLabel->setPixmap(*this->displayBuffer);
    this->displayLabel->update();
}


