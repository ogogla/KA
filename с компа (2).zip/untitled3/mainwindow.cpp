#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    this->resize(640, 480);
    this->setWindowTitle("Animation");
    this->wawe_timer = new QTimer();
    this->sun_rotation_timer = new QTimer();
    this->sun_move_timer = new QTimer();
    connect(this->wawe_timer, &QTimer::timeout, this, &MainWindow::onWaweTimer);
    connect(this->sun_rotation_timer, &QTimer::timeout, this, &MainWindow::onSunRotationTimer);
    connect(this->sun_move_timer, &QTimer::timeout, this, &MainWindow::onSunMoveTimer);
    this->wawe_phase = 0;
    this->sun_rotation_phase = 0;
    this->sun_move_phase = 0;

    this->rand = new QRandomGenerator(QTime::currentTime().msec());

    this->drawSun();
    this->drawShip();

    this->wawe_timer->start(50);
    this->sun_rotation_timer->start(50);
    this->sun_move_timer->start(50);
}

MainWindow::~MainWindow() {
    delete this->ship;
    this->sun_rotation_timer->stop();
    delete this->sun_rotation_timer;
    this->sun_move_timer->stop();
    delete this->sun_move_timer;
    delete this->sun;
    this->wawe_timer->stop();
    delete this->wawe_timer;
    delete this->rand;
}

void MainWindow::drawShip() {
    this->ship = new QPixmap(SHIP_WIDTH, SHIP_HEIGHT);
    this->ship->fill(Qt::transparent);

    QPainter p;
    p.begin(this->ship);

    QPainterPath pipes;
    QPolygonF pipe1_polygon;
    pipe1_polygon << QPointF(42, 145)
                  << QPointF(42, 92)
                  << QPointF(67, 92)
                  << QPointF(67, 145);
    pipes.addPolygon(pipe1_polygon);
    QPolygonF pipe2_polygon;
    pipe2_polygon << QPointF(78, 145)
                  << QPointF(78, 78)
                  << QPointF(109, 78)
                  << QPointF(109, 145);
    pipes.addPolygon(pipe2_polygon);
    QPolygonF pipe3_polygon;
    pipe3_polygon << QPointF(121, 145)
                  << QPointF(121, 99)
                  << QPointF(145, 99)
                  << QPointF(145, 145);
    pipes.addPolygon(pipe3_polygon);
    QLinearGradient pipes_gradient(42, 92, 42, 145);  // Направление сверху вниз
    pipes_gradient.setColorAt(0.0, QColor(90, 70, 70));    // Тёмный верх
    pipes_gradient.setColorAt(0.5, QColor(70, 50, 50));    // Очень тёмный центр
    pipes_gradient.setColorAt(1.0, QColor(60, 40, 40));    // Почти чёрный низ
    p.setBrush(pipes_gradient);
    p.setPen(QPen(QColor(60, 60, 60), 1));  // Тёмная обводка
    p.drawPath(pipes);

    QPainterPath build;
    QPolygonF build_polygon;
    build_polygon << QPointF(60, 145)
                  << QPointF(60, 115)
                  << QPointF(121, 115)
                  << QPointF(121, 145);
    build.addPolygon(build_polygon);
    QLinearGradient build_gradient;
    build_gradient.setColorAt(0.0, QColor(160, 160, 160));
    build_gradient.setColorAt(0.5, QColor(140, 140, 140));
    build_gradient.setColorAt(1.0, QColor(130, 130, 130));
    p.setBrush(build_gradient);
    p.setPen(Qt::NoPen);
    p.drawPath(build);

    p.setPen(QColor(110, 110, 110));
    const int window_margin = 10;
    bool fl_y = false;
    bool fl_b = false;
    for(int i = 0; i < 5; ++i){
        int r = this->rand->bounded(0, 100);
        if (r % 3){
            p.setBrush(QColor(100, 149, 237));
            fl_b = true;
        } else {
            p.setBrush(QColor(255, 220, 51));
            fl_y = true;
        }
        if (i == 4 && !fl_y) p.setBrush(QColor(255, 220, 51));
        if (i == 4 && !fl_b) p.setBrush(QColor(100, 149, 237));
        p.drawEllipse(65 + i * window_margin, 120, 7, 7);
    }

    QPainterPath body;
    QPolygonF body_polygon;
    body_polygon << QPointF(15, 115)
                 << QPointF(35, 115)
                 << QPointF(55, 135)
                 << QPointF(125, 135)
                 << QPointF(152, 118)
                 << QPointF(188, 116)
                 << QPointF(165, 185)
                 << QPointF(33, 185)
                 << QPointF(18, 135)
                 << QPointF(15, 115);
    body.addPolygon(body_polygon);
    QLinearGradient body_gradient(0, 125, 0, 180);
    body_gradient.setColorAt(0, QColor(80, 80, 80));    // Тёмно-серый
    body_gradient.setColorAt(1, QColor(30, 30, 30));    // Почти чёрный
    p.setBrush(body_gradient);
    p.setPen(QPen(Qt::black, 2));
    p.drawPath(body);

    p.end();
}

void MainWindow::drawSun()
{
    this->sun = new QPixmap(140, 140);
    this->sun->fill(Qt::transparent);

    QPainter p;
    p.begin(this->sun);
    p.setPen(QColor(244, 169, 0));

    int sunX = 35;
    int sunY = 35;
    int sun_width = 70;
    int sun_height = 70;
    p.setBrush(QColor(253, 233, 16));
    p.drawEllipse(sunX, sunY, sun_width, sun_height);

    int ray_count = 16;
    int ray_length = 25;
    int ray_width = 6;
    int centerX = (2 * sunX + sun_width) / 2;
    int centerY = (2 * sunY + sun_height) / 2;
    for(int i = 0; i < ray_count; ++i){
        double place_angle = 2 * M_PI / ray_count;

        QTransform t;
        t.translate(centerX, centerY);
        t.rotateRadians(i * place_angle);
        t.translate(sun_width / 2 + 5, -ray_width / 2);

        p.setTransform(t);
        p.drawRect(0, 0, ray_length, ray_width);
    }

    p.end();
}

double MainWindow::wawe_calc(double x)
{
    return LEVEL * this->height() + AMPLITUDE * std::sin(x / LAMBDA * M_PI + wawe_phase);
}

// Выкидывает проможуточные цвета (по умному - интерполяция цвета), здесь 0 - первый цвет, 1 - второй цвет, всё зависит от rate
QColor MainWindow::mix_colors(QColor color1, QColor color2, double rate)
{
    double r = (color2.redF() - color1.redF()) * rate + color1.redF();
    double g = (color2.greenF() - color1.greenF()) * rate + color1.greenF();
    double b = (color2.blueF() - color1.blueF()) * rate + color1.blueF();
    return QColor::fromRgbF(r, g, b);
}

void MainWindow::paintEvent(QPaintEvent *event) {
    QPainter p;
    p.begin(this);
    p.setRenderHint(QPainter::Antialiasing); // Сглаживане

    // Sun move
    double sunX = this->width() - this->width() * std::sin(this->sun_move_phase / 2.0);
    double sunY = (LEVEL * this->height() - this->sun->height() / 2.0) - std::sin(this->sun_move_phase) * ((LEVEL * this->height() - this->sun->height() / 2.0));

    // It's фон
    // 0 — верх, 1 — низ
    double t_h = sunY / double(this->height());

    QColor dawnT = QColor("#FFCF87");
    QColor dawnB = QColor("#FFEFCF");
    QColor noonT = QColor("#87CEEB");
    QColor noonB = QColor("#E0FFFF");
    QColor duskT = QColor("#FF4500");
    QColor duskB = QColor("#8B0000");

    // Рассвет - день - закат
    QColor top, bottom;
    if (t_h < 0.5) {
        // От рассвета к зенитц
        double f = t_h / 0.5;
        top = mix_colors(noonT, dawnT, f);
        bottom = mix_colors(noonB, dawnB, f);
    } else {
        // От зениту к закату
        double f = (t_h - 0.5) / 0.5;
        top = mix_colors(duskT, noonT, f);
        bottom = mix_colors(duskB, noonB, f);
    }

    // Градиент "от солнца"
    QPointF centerr(width()/2.0, height()/2.0);
    QPointF dir = QPointF(sunX, sunY) - centerr; // Типо вектор к солнышку
    QPointF start = centerr + dir * 2.0; // умножаем для красоты (наугад) :)
    QPointF end = centerr - dir * 2.5;

    QLinearGradient background_grad(start, end);
    background_grad.setColorAt(0.0, top);
    background_grad.setColorAt(1.0, bottom);

    p.setPen(Qt::NoPen);
    p.setBrush(background_grad);
    p.drawRect(rect());

    // Sun rotation
    QPointF center(sunX + this->sun->width()/2.0, sunY + this->sun->height()/2.0);
    p.save();
    p.translate(center);
    double angle_deg = this->sun_rotation_phase * 180.0 / M_PI; // Делаем угол из радиан в градусы
    p.rotate(angle_deg);
    p.translate(-this->sun->width()/2.0, -this->sun->height()/2.0);
    p.drawPixmap(0, 0, *this->sun);
    p.restore();

    // Кораблик делает вжух-вжух лево-право
    double x1 = (this->width() - SHIP_WIDTH) / 2;
    double x2 = x1 + SHIP_WIDTH;
    double y1 = this->wawe_calc(x1);
    double y2 = this->wawe_calc(x2);
    double alpha = std::atan((y2 - y1) / (x2 - x1));
    QTransform ship_t;
    ship_t.rotateRadians(alpha);
    QPixmap _ship = this->ship->transformed(ship_t);
    p.drawPixmap(
        (this->width() - _ship.width()) / 2,
        this->height() * LEVEL - _ship.height() + 2 * AMPLITUDE,
        _ship
    );

    // Волны
    p.setPen(QColor("#00ffff"));
    p.setBrush(QColor("#00ffff"));
    std::vector<QPointF> points;
    for (int x = 0; x < this->width(); ++x) {
        double y = this->wawe_calc(x);
        points.push_back(QPointF(x, y));
    }
    points.push_back(QPointF(this->width(), this->height()));
    points.push_back(QPointF(0, this->height()));
    p.drawPolygon(points.data(), points.size());

    p.end();
}

void MainWindow::onWaweTimer() {
    wawe_phase += 0.1;
    if (std::fabs(this->wawe_phase - 2 * M_PI) < 0.1)
        this->wawe_phase = 0;
    this->update();
}

void MainWindow::onSunRotationTimer()
{
    this->sun_rotation_phase += 0.05;
    if (std::fabs(this->sun_rotation_phase - 2 * M_PI) < 0.05)
        this->sun_rotation_phase = 0;
    this->update();
}

void MainWindow::onSunMoveTimer()
{
    this->sun_move_phase += 0.01;
    if (std::fabs(this->sun_move_phase - 1 * M_PI) < 0.01)
        this->sun_move_phase = 0;
    this->update();
}
