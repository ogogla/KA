#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QPixmap>
#include <QPainter>
#include <QPaintEvent>
#include <QColor>
#include <QPointF>
#include <QBrush>
#include <QPen>
#include <QTransform>
#include <QPainterPath>
#include <QPolygonF>
#include <QLinearGradient>
#include <QRandomGenerator>
#include <QTime>

#include <cmath>
#include <vector>

#define LAMBDA 200.0
#define AMPLITUDE 20.0
#define LEVEL 0.7
#define SHIP_WIDTH 200
#define SHIP_HEIGHT 200

class MainWindow : public QMainWindow
{
    Q_OBJECT
    QRandomGenerator* rand;
    QPixmap *ship, *sun, *background;
    void drawShip();
    void drawSun();
    double wawe_phase, sun_rotation_phase, sun_move_phase;
    QTimer *wawe_timer, *sun_rotation_timer, *sun_move_timer;
    double wawe_calc(double x);
    QColor mix_colors(QColor color1, QColor color2, double rate);

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *event) override;

public slots:
    void onWaweTimer();
    void onSunRotationTimer();
    void onSunMoveTimer();
};
#endif // MAINWINDOW_H
