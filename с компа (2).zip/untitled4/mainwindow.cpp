#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    this->setWindowTitle("Balls");
    this->resize(600, 600);
    this->field = new Field();
    setCentralWidget(field);
}

MainWindow::~MainWindow() {

}
