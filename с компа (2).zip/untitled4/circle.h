#ifndef CIRCLE_H
#define CIRCLE_H

#include <QObject>
#include <QColor>
#include <QWidget>
#include <QPointF>
#include <QColor>

class Circle : public QObject
{
    Q_OBJECT
    QColor *color;
    double speedX, speedY;
    QPointF *center;

public:
    Circle(QWidget *parent = nullptr,  QPointF p = QPointF(0.0, 0.0), double sX = 0.0, double sY = 0.0, QColor c = QColor(Qt::red));
    ~Circle();
    void move();
    void bounce();
    QColor getColor();
    QPointF getCenter();

signals:
protected:
};

#endif // CIRCLE_H
