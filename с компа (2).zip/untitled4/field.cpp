#include "field.h"

Field::Field(QWidget *parent) :
    QWidget(parent)
{
    setMouseTracking(true);
    this->timer = new QTimer();
    connect(this->timer, &QTimer::timeout, this, &Field::onTimer);

    this->timer->start(10);
}

Field::~Field()
{
    this->timer->stop();
    delete this->timer;
    for(auto c : circles) delete c;
}

void Field::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    p.fillRect(rect(), Qt::white);

    if (this->arrow_fl) {
        p.setPen(QPen(Qt::black, 2));
        p.drawLine(this->arrow_pos1, this->arrow_pos2);
    }

    p.setPen(Qt::NoPen); // Скажем обводке "Нет!"

    for(Circle *c : this->circles) {
        p.setBrush(c->getColor()); // Меняем заполнение на цвет шарика
        p.drawEllipse(c->getCenter(), 10, 10); // Радиус :)
    }
}

void Field::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        this->arrow_fl = true;
        this->arrow_pos1 = event->position();
        this->arrow_pos2 = event->position();
        update();
    }
}

void Field::mouseMoveEvent(QMouseEvent *event)
{
    if (this->arrow_fl) {
        this->arrow_pos2 = event->position();
        update();
    }
}

void Field::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        this->arrow_fl = false;

        double speedX = (this->arrow_pos2.x() - this->arrow_pos1.x()) * 0.05; // Множитель чувствительности
        double speedY = (this->arrow_pos2.y() - this->arrow_pos1.y()) * 0.05; // Натяжение = СКОРОСТЬ!!!

        auto newCircle = new Circle(this, this->arrow_pos1, speedX, speedY, this->randColor());
        circles.push_back(newCircle);
        update();
    }
}

void Field::onTimer()
{
    for(Circle *c : this->circles){
        c->move();
        c->bounce();
    }
    update();
}

QColor Field::randColor()
{
    return QColor(QRandomGenerator::global()->bounded(0, 255),
                  QRandomGenerator::global()->bounded(0, 255),
                  QRandomGenerator::global()->bounded(0, 255));
}
