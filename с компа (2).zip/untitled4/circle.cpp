#include "circle.h"

Circle::Circle(QWidget* parent, QPointF p, double sX, double sY, QColor c):
    QObject(parent),
    center(new QPointF(p)),
    color(new QColor(c)),
    speedX(sX),
    speedY(sY)
{}

Circle::~Circle() {
    delete this->center;
    delete this->color;
}

// Новое положение шарика каждый кадр
void Circle::move()
{
    this->center->rx() += speedX;
    this->center->ry() += speedY;
}

// Шарики делают "Боньк!"
void Circle::bounce() {
    QWidget *parentWidget = qobject_cast<QWidget*>(parent()); // Безопасное приведение типов, ибо так надо для получения размеров

    if (parentWidget->width() < this->center->rx() || this->center->rx() < 0.0) {
        this->speedX *= -1;
    }
    if (parentWidget->height() < this->center->ry() || this->center->ry() < 0.0) {
        this->speedY *= -1;
    }
}

QColor Circle::getColor()
{
    return *this->color;
}

QPointF Circle::getCenter()
{
    return *this->center;
}
