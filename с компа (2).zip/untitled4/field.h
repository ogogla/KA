#ifndef FIELD_H
#define FIELD_H

#include <QObject>
#include <QWidget>
#include <QMouseEvent>
#include <QPainter>
#include <QTimer>
#include <QRandomGenerator>
#include <QLineF>
#include <QPen>

#include "circle.h"

#include <list>

class Field : public QWidget
{
    Q_OBJECT
    QTimer *timer;
    QPointF arrow_pos1, arrow_pos2;
    bool arrow_fl = false;

public:
    explicit Field(QWidget *parent = nullptr);
    ~Field();

signals:
    void mouse_pressed(QPoint pos);
    void mouse_dragged(QPoint pos);
    void mouse_released(QPoint pos);

protected:
    void paintEvent(QPaintEvent *) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private:
    std::list<Circle*> circles;
    void onTimer();
    QColor randColor();
};

#endif // FIELD_H
