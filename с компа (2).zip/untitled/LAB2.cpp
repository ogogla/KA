#include <iostream>
using namespace std;

int main() {
    bool x, y;
    double a, b;
    cin >> x;
    cin >> y;
    cin >> a;
    cin >> b;
    bool result = (!x) || (x && y) || (a != b);
    cout <<result << endl;
    return 0;
}