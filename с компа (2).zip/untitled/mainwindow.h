#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QFile>
#include <QTextStream>

#include <QMainWindow>
#include <QLineEdit>
#include <QPushButton>
#include <QListWidget>
#include <QWidget>
#include <QLayout>
#include <QVBoxLayout>
#include <QInputDialog>

class MainWindow : public QMainWindow
{
    Q_OBJECT
    QWidget *_centralWidget;
    QVBoxLayout *layout_v;
    QPushButton *button_add;
    QPushButton *button_delete;
    QListWidget *task_list;

    QString get_task_name();
    void save_tasks_file(const QString &file_path);
    void load_tasks_file(const QString &file_path);

private slots:
    void click_add();
    void click_delete();

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
};
#endif // MAINWINDOW_H
