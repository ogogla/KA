#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    this->resize(640, 480);
    this->setMinimumSize(320, 240);
    this->setWindowTitle("Task_List");
    this->_centralWidget = new QWidget(this);
    this->setCentralWidget(this->_centralWidget);

    //брать стили с web-профессионалы никто не запрещал :)    R-сырая строка
    this->_centralWidget->setStyleSheet(R"(
        QWidget {
            background-color: #2c3e50; /* Тёмный фон */
            color: white;
        }

        QPushButton {
            background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,
                                        stop:0 #ff7eb3, stop:1 #ff758c); /* Градиент */
            color: white;
            font-size: 16px;
            font-weight: bold;
            border: 2px solid #ff5370;
            border-radius: 10px;
            padding: 10px 20px;
            transition: all 0.3s ease-in-out;
        }

        QPushButton:hover {
            background: qlineargradient(spread:pad, x1:0, y1:1, x2:1, y2:0,
                                        stop:0 #ff5370, stop:1 #ff758c); /* Обратный градиент */
            border-color: #ff2e63;
            transform: scale(1.05); /* Лёгкое увеличение */
        }

        QPushButton:pressed {
            background: #ff2e63;
            border-color: #d90429;
            padding: 9px 19px; /* Эффект нажатия */
        }

        QPushButton:disabled {
            background: #7f8c8d;
            color: #bdc3c7;
            border-color: #95a5a6;
        }
    )");

    this->layout_v = new QVBoxLayout();
    this->_centralWidget->setLayout(this->layout_v);

    this->task_list = new QListWidget(this->_centralWidget);

    this->button_add = new QPushButton("Add", this->_centralWidget);
    this->button_delete = new QPushButton("Delete", this->_centralWidget);

    connect(this->button_add, &QPushButton::clicked, this, &MainWindow::click_add);
    connect(this->button_delete, &QPushButton::clicked, this, &MainWindow::click_delete);

    this->layout_v->addWidget(this->task_list);
    this->layout_v->addWidget(this->button_add);
    this->layout_v->addWidget(this->button_delete);

    this->load_tasks_file("tasks.json");
}

QString MainWindow::get_task_name() {
    bool ok;
    QInputDialog *inputDialog = new QInputDialog(this);
    inputDialog->setWindowTitle("Введите название");
    inputDialog->setLabelText("Название задачи:");
    inputDialog->setTextValue("");
    inputDialog->setInputMode(QInputDialog::TextInput);

    inputDialog->resize(400, 100);

    if (inputDialog->exec() == QDialog::Accepted) {
        return inputDialog->textValue();
    } else {
        return "";
    }
}

void MainWindow::click_add(){
    qInfo() << "add";
    QString name = this->get_task_name();
    if (name.isEmpty()) return;
    QListWidgetItem* item = new QListWidgetItem(name);
    this->task_list->addItem(item);
}

void MainWindow::click_delete(){
    qInfo() << "del";
    QListWidgetItem* item = this->task_list->currentItem();
    if (item) {
        delete this->task_list->takeItem(this->task_list->row(item));
    }
}

void MainWindow::save_tasks_file(const QString &file_path){
    qInfo() << "save";
    QJsonArray tasks_js_arr;

    for (int i = 0; i < this->task_list->count(); ++i) {
        QListWidgetItem* item = this->task_list->item(i);
        tasks_js_arr.append(item->text());
    }

    QJsonObject root;
    root["tasks"] = tasks_js_arr;

    QJsonDocument doc(root);

    QFile file(file_path);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {  // Перезапись файла
        file.write(doc.toJson(QJsonDocument::Indented));
        file.close();
    } else {
        qInfo() << "blin";
    }
}

void MainWindow::load_tasks_file(const QString &file_path) {
    qInfo() << "load";
    QFile file(file_path);

    if (!file.exists()) {
        qInfo() << "blin, lose file";
        return;
    }

    if (!file.open(QIODevice::ReadOnly)) {
        qInfo() << "blin";
        return;
    }

    QByteArray data = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        qInfo() << "blin, wrong in JSON";
        return;
    }

    QJsonObject root = doc.object();
    QJsonArray tasks_js_arr = root["tasks"].toArray();

    for (const QJsonValue &val : tasks_js_arr) {
        QString task_name = val.toString();
        if (!task_name.isEmpty()) {
            this->task_list->addItem(task_name);
        }
    }
}

MainWindow::~MainWindow() {
    this->save_tasks_file("tasks.json");
    while (this->task_list->count() > 0) {
        delete this->task_list->takeItem(0);
    }
    delete this->task_list;
    delete this->button_delete;
    delete this->button_add;
    delete this->layout_v;
    delete this->_centralWidget;
}
